package SampleInheritance;

/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 *
 */

public class Test_toString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		A a1 = new A();
		System.out.println(a1);
		
		A b1 = new B();
		System.out.println(b1);
		
	}

}
