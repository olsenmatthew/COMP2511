package Shapes;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 *
 */

public class GraphicalCircle extends Circle {
	
	Color  outline, fill;
    public GraphicalCircle(){
            super();
            this.outline = Color.black;  
            this.fill = Color.white;
    }
    // Another simple constructor
    public GraphicalCircle(int x, int y, 
                    int r, Color o, Color f){
        super(x, y, r);
        this.outline = o; this.fill = f;
    }

	public void draw(Graphics  g) {
		g.setColor(outline);
		g.drawOval(x-r, y-r, 2*r, 2*r);
		g.setColor(fill);
		g.fillOval(x-r, y-r, 2*r, 2*r);
	}

}


