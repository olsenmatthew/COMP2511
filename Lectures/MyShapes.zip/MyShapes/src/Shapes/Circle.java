package Shapes;

/**
 * Demo file, it may not be correct and/or complete.  
 * Please watch the corresponding lecture(s) for more explanations.
 * 
 * @author ashesh
 *
 */

public class Circle  extends Shape {

	protected static final double pi = 3.14159; 
	protected  int  x, y;
	protected  int  r;
	protected static int count_circle = 0;

	// Very simple constructor
	public Circle(){
		this.x = 1;
		this.y = 1;
		this.r = 1;

		count_circle++; 
		count_shapes++;
	}
	// Another simple constructor
	public Circle(int x, int y, int r){
		this.x = x;
		this.y = y;
		this.r = r;

		count_circle++; 
		count_shapes++;
	}

	/**
	 * Below, methods that return the circumference 
	 * area of the circle
	 */
	public  double  circumference( ) {  
		return 2 * pi * r ; 
	}
	public  double  area ( ) {
		return  pi * r * r ; 
	}
	public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getR() {
		return r;
	}
	public void setR(int r) {
		this.r = r;
	}

	
	
}
